let menuIcon = document.querySelector(".hamburger-menu");
let navbar = document.querySelector(".navbar");

menuIcon.addEventListener("click", () => {

        navbar.classList.toggle("change");
    })
    // **************************Gallery Page creation*********************************************
let imagesArray = [{
        "location": "assets/images/puppy_1.jpg",
        "url": "https://www.akc.org",
    },
    {
        "location": "assets/images/puppy_2.jpg",
        "url": "https://www.akc.org",
    },
    {
        "location": "assets/images/puppy_3.jpg",
        "url": "https://www.akc.org",
    },
    {
        "location": "assets/images/puppy_4.jpg",
        "url": "https://www.akc.org",
    },
    {
        "location": "assets/images/puppy_5.jpg",
        "url": "https://www.akc.org",
    },
    {
        "location": "assets/images/puppy_6.jpg",
        "url": "https://www.akc.org",
    },
    {
        "location": "assets/images/puppy_7.jpg",
        "url": "https://www.akc.org",
    },
    {
        "location": "assets/images/puppy_8.jpg",
        "url": "https://www.akc.org",
    },
    {
        "location": "assets/images/puppy_9.jpg",
        "url": "https://www.akc.org",
    },
    {
        "location": "assets/images/puppy_10.jpg",
        "url": "https://www.akc.org",
    },
    {
        "location": "assets/images/puppy_11.jpg",
        "url": "https://www.akc11.org",
    },
    {
        "location": "assets/images/puppy_12.jpg",
        "url": "https://www.akc12.org",
    }

];
// let imgAnchor = document.createElement('a');
// let imgAnchorTxtNode = document.createTextNode('');

function myFunction() {


    let grids = document.querySelectorAll(".grid");
    for (let i = 0; i < grids.length; i++) {
        let imgAnchor = document.createElement('a');
        imgAnchor.setAttribute('href', imagesArray[i]["url"]);
        let imgInsideAnchor = document.createElement('IMG');
        imgInsideAnchor.setAttribute('src', imagesArray[i]["location"]);
        imgAnchor.appendChild(imgInsideAnchor);
        // grids[i].appendChild(document.createTextNode(`pic ${i+1}`));
        grids[i].appendChild(imgAnchor);
        // imgAnchorTxtNode = document.createTextNode('');
        // console.log(imgAnchor);

    }
}
myFunction();

// ************************** end of Gallery Page creation*********************************************

// ************************** Beginning of Calendar Page creation*********************************************
let monthsDescripters = {
    0: "January",
    1: "February",
    2: "March",
    3: "April",
    4: "May",
    5: "June",
    6: "July",
    7: "August",
    8: "September",
    9: "October",
    10: "November",
    11: "December"

};
let monthsReverseDescripters = {
    "January": 0,
    "February": 1,
    "March": 2,
    "April": 3,
    "May": 4,
    "June": 5,
    "July": 6,
    "August": 7,
    "September": 8,
    "October": 9,
    "November": 10,
    "December": 11

};
let weekDayHeadingsArray = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

// console.log(monthsReverseDescripters["January"]);
let d = new Date(2020, 4, 0);
// console.log(d.getDate());
let calendarArea = document.querySelector(".calendar");
let mainCalendarTable = document.querySelector(".mainTable");
// console.log(d);

const submitBtn = document.querySelector("#submitBtn");
const selectElement = document.querySelector(".calendarList");
const calendarHeading = document.querySelector(".calendarHeading thead tr th");
// console.log(calendarHeading);
// calendarHeading.style.backgroundColor = "#fff";

submitBtn.addEventListener("click", () => {
    // console.log(selectElement.value);
    // const moonLanding = new Date(`${selectElement.value} 20, 1 00:20:18`);
    mainCalendarTable.innerText = "";
    const moonLanding = new Date(2020, monthsReverseDescripters[selectElement.value], 1);
    // console.log(selectElement.value);
    // console.log(moonLanding);

    calendarHeading.innerHTML = monthsDescripters[moonLanding.getMonth()];
    let NumDaysInMonth = daysInMonth(moonLanding.getMonth() + 1, 2020);
    let firstDayOfMonth = moonLanding.getDay();
    // calendarHeading.innerHTML = firstDayOfMonth;
    // console.log(moonLanding.getMonth()); // (January gives 0)

    buildTable(NumDaysInMonth, firstDayOfMonth);
});
refreshBtn.addEventListener("click", () => {
    window.location.reload(false);
});

function daysInMonth(month, year) {
    return new Date(year, month, 0).getDate();
}

// function buildTable(numdays, firstday) {

//     console.log("test");
//     // building an array of the days in the month
//     let monthDaysArr = [];
//     for (let i = 1; i <= numdays; i++) {
//         monthDaysArr.push(i);
//     }
//     console.log(monthDaysArr);
//     // processing headings row
//     let rowHeadings = document.createElement('tr');
//     for (let j = 0; j <= 6; j++) {
//         console.log(weekDayHeadingsArray[j]);
//         let textnode = document.createTextNode(weekDayHeadingsArray[j]);
//         let column = document.createElement('th');
//         column.appendChild(textnode);
//         rowHeadings.appendChild(column);
//         // monthDaysArr.shift();
//     }
//     mainCalendarTable.appendChild(rowHeadings);

//     // processing row 1
//     let row1 = document.createElement('tr');
//     // pushing in empty tds
//     console.log(firstday);
//     for (let j = 0; j < firstday; j++) {
//         row1.appendChild(document.createElement('td'));
//     }
//     for (let j = firstday; j <= 6; j++) {
//         let textnode = document.createTextNode(monthDaysArr[j - firstday]);
//         let column = document.createElement('td');
//         column.appendChild(textnode);
//         row1.appendChild(column);
//         // monthDaysArr.shift();
//     }
//     for (let j = firstday; j <= 6; j++) {
//         monthDaysArr.shift();
//     }
//     mainCalendarTable.appendChild(row1);
//     console.log(row1);
//     console.log(monthDaysArr);

//     // processing row 2
//     let row2 = document.createElement('tr');
//     for (let j = 0; j <= 6; j++) {
//         let textnode = document.createTextNode(monthDaysArr[j]);
//         let column = document.createElement('td');
//         column.appendChild(textnode);
//         row2.appendChild(column);
//         // monthDaysArr.shift();
//     }
//     for (let j = 0; j <= 6; j++) {
//         monthDaysArr.shift();
//     }
//     mainCalendarTable.appendChild(row2);

//     // processing row 3
//     let row3 = document.createElement('tr');
//     for (let j = 0; j <= 6; j++) {
//         let textnode = document.createTextNode(monthDaysArr[j]);
//         let column = document.createElement('td');
//         column.appendChild(textnode);
//         row3.appendChild(column);
//         // monthDaysArr.shift();
//     }
//     for (let j = 0; j <= 6; j++) {
//         monthDaysArr.shift();
//     }
//     mainCalendarTable.appendChild(row3);

//     // processing row 4
//     let row4 = document.createElement('tr');
//     for (let j = 0; j <= 6; j++) {
//         let textnode = document.createTextNode(monthDaysArr[j]);
//         let column = document.createElement('td');
//         column.appendChild(textnode);
//         row4.appendChild(column);
//         // monthDaysArr.shift();
//     }
//     for (let j = 0; j <= 6; j++) {
//         monthDaysArr.shift();
//     }
//     mainCalendarTable.appendChild(row4);

//     // processing row 5
//     let row5 = document.createElement('tr');
//     for (let j = 0; j < monthDaysArr.length; j++) {
//         let textnode = document.createTextNode(monthDaysArr[j]);
//         let column = document.createElement('td');
//         column.appendChild(textnode);
//         row5.appendChild(column);
//         // monthDaysArr.shift();
//     }
//     for (let j = monthDaysArr.length; j < 7; j++) {
//         row5.appendChild(document.createElement('td'));
//     }
//     for (let j = 0; j <= 6; j++) {
//         monthDaysArr.shift();
//     }
//     mainCalendarTable.appendChild(row5);

// }

function buildTable(numdays, firstday) {

    // console.log("test");
    // building an array of the days in the month
    let rowHeadings = document.createElement('tr');
    for (let j = 0; j <= 6; j++) {
        // console.log(weekDayHeadingsArray[j]);
        let textnode = document.createTextNode(weekDayHeadingsArray[j]);
        let column = document.createElement('th');
        column.appendChild(textnode);
        rowHeadings.appendChild(column);
        // monthDaysArr.shift();
    }
    mainCalendarTable.appendChild(rowHeadings);
    let monthDaysArr = [];
    for (let i = 1; i <= numdays; i++) {
        let textnodetd = document.createTextNode(i);
        let columntd = document.createElement('td');
        columntd.appendChild(textnodetd);
        monthDaysArr.push(columntd);
    }
    for (let j = 0; j < firstday; j++) {
        let textnodetd = document.createTextNode('');
        let columntd = document.createElement('td');
        columntd.appendChild(textnodetd);
        monthDaysArr.unshift(columntd);
    }
    while (monthDaysArr.length > 6) {
        let row = document.createElement('tr');
        for (let i = 0; i < 7; i++) {
            row.appendChild(monthDaysArr[i]);
            // console.log(monthDaysArr[i]);
        }
        for (let i = 0; i < 7; i++) {
            monthDaysArr.shift();
        }
        mainCalendarTable.appendChild(row);
    }

    if (monthDaysArr.length > 0) {
        let finalRow = document.createElement('tr');
        for (let i = 0; i < monthDaysArr.length; i++) {
            finalRow.appendChild(monthDaysArr[i]);
        }
        for (let i = monthDaysArr.length; i < 7; i++) {
            let textnodetd = document.createTextNode('');
            let columntd = document.createElement('td');
            columntd.appendChild(textnodetd);
            finalRow.appendChild(columntd);
        }
        mainCalendarTable.appendChild(finalRow);
    }



}
// ************************** End of Calendar Page creation*********************************************